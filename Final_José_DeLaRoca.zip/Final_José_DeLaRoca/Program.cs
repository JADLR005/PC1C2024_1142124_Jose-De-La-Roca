﻿
using Final_José_DeLaRoca;

Usuarios[] Usuarios = new Usuarios[100];    //Hacemos un arreglo con el nombre de "Usuarios" donde se guardarán los usuarios que podrán ingresarse (Se inicializa a 100 porque esa será la cantidad máxima de usuarios que caben en el sistema)
Libros[] Libros = new Libros[100];      //Creamos otro arreglo de libros para guardar todos los libros que se vayan prestando
Prestamos[] Prestamos = new Prestamos[100];     //Creamos un último arreglo de préstamos donde se guardarán todos los datos de los préstamos que se realicen

int ConteoUsuarios = 0;     //Creamos una variable de tipo int con nombre "ConteoUsuarios" para llevar el conteo de los usuarios que ingresan (se inicializa a 0)
int ConteoLibros = 0;   //Creamos otra variable de tipo int con nombre "ConteoLibros" para llevar el conteo de los libros que se van prestando
int ConteoPrestamos = 0;    //Creamos una última variable tipo int con nombre "ConteoPrestamos" para llevar el conteo de los préstamos que se realizan
int Opcion = 0;

do
{
    //Menú interactivo que se muestra al entrar al sistema de la biblioteca
    Console.WriteLine("-------Bienvenido a la Biblioteca de la Universidad Rafael Landívar---------");
    Console.WriteLine("1. Ingresa tus datos");
    Console.WriteLine("2. Mostrar los datos");
    Console.WriteLine("3. Devolver un libro prestado");
    Console.WriteLine("4. Salir del sistema de la biblioteca");
    Console.WriteLine("Por favor selecciona una opción válida");
    Opcion = int.Parse(Console.ReadLine());

    switch (Opcion)
    {
        case 1: 
            int Opcion2 = 0;
            do  //Ciclo para mostrar varias veces el menú de ingresa tus datos hasta que el usuario elija la opción de salir
            {
            Console.WriteLine("-------Ingresa tus datos------");
            Console.WriteLine("1. Ingresa tus datos personales");
            Console.WriteLine("2. Ingresa el libro que quieres prestar");
            Console.WriteLine("3. Registra tu préstamo en el sistema");
            Console.WriteLine("4. Salir de Ingresa tus datos");
            Opcion2 = int.Parse(Console.ReadLine());

            if(Opcion2 == 1)    //Si elige la primera opción, le salta el ingreso de los datos personales
            {

                Usuarios[ConteoUsuarios] = new Usuarios();
                Usuarios validar = new Usuarios();  //Creación de método para utilizar las funcines de Usuarios
                Console.WriteLine("Ingresa tu nombre");
                Usuarios[ConteoUsuarios].Nombre = Console.ReadLine();
                Console.WriteLine("Ingresa tu apellido");
                Usuarios[ConteoUsuarios].Apellidos = Console.ReadLine();
                Console.WriteLine("Ingresa tu carné de la Universidad");
                Usuarios[ConteoUsuarios].Carné = Console.ReadLine();
                validar.ValidarCarne(Usuarios[ConteoUsuarios].Carné);   //Utilización del método ValidarCarne de la clase Usuarios
                ConteoUsuarios++;
            }
            else if (Opcion2 == 2)  //Si elige la opción 2, le salta el ingreso del libro que quiere prestar
            {
                Libros[ConteoLibros] = new Libros();
                Console.WriteLine("Ingresa el título del libro");
                Libros[ConteoLibros].Titulo = Console.ReadLine();
                Console.WriteLine("Ingresa el autor del libro");
                Libros[ConteoLibros].Autor = Console.ReadLine();
                Console.WriteLine("Ingresa el código del libro (Su formato es L(2 números)RL)");
                Libros[ConteoLibros].CódigoLibro = Console.ReadLine();
                Libros validar = new Libros();  //Creación de método para utilizar las funciones de la clase Libros
                validar.ValidarLibro(Libros[ConteoLibros].CódigoLibro);     //Utilización del método ValidarLibro de la clase Libros
                ConteoLibros++;
            }
            else if (Opcion2 == 3)  //Si elige la opción 3, las validaciones se encargan de que esté un libro ingresado
            {
                if (ConteoUsuarios == 0 || ConteoLibros == 0)
                {
                    Console.WriteLine("Por favor, antes que nada, ingresa tus datos personales y el libro que quieres prestar");
                }else{      //Si hay por lo menos un libro ingresado, esta validación se encarga de igualar los datos del if anterior, con los que se utilizarán para mostrar los datos y así no tener que colocar nuevamente los datos.
                Prestamos[ConteoPrestamos] = new Prestamos();
                Console.WriteLine("Carné igualado al que habías colocado en el ingreso de datos...");
                Prestamos[ConteoPrestamos].CarneLandivar = Usuarios[ConteoUsuarios - 1].Carné;
                Console.WriteLine("Código de libro igualado al que habías colocado en el ingreso del libro que querías...");
                Prestamos[ConteoPrestamos].CodigoLibroLandivar = Libros[ConteoLibros - 1].CódigoLibro;
                Console.WriteLine("");
                Console.WriteLine("Préstamo registrado correctamente :)");
                ConteoPrestamos++;
                }
            }
        }while(Opcion2 != 4);
            break;

        case 2:
            int Opcion3 = 0;
            do{
                //Menú con ciclo para que se muestre varias veces hasta que el usuario elija la opción de salir
            Console.WriteLine("-----Mostrar todos los datos-----");
            Console.WriteLine("1. Listado de libros prestados por usuario");
            Console.WriteLine("2. Consultar el catálogo");
            Console.WriteLine("3. Listado de usuarios activos");
            Console.WriteLine("4. Salir de Mostrar todos los datos");
            Opcion3 = int.Parse(Console.ReadLine());

            if (Opcion3 == 1) //Si elije la opción 1 se mostrarán los libros que prestó un usuario
            {
                Console.WriteLine("Ingresa el carné del usuario al que quieres ver el litado de libros prestado:");
                string carnelistado = Console.ReadLine();
                for (int i = 0; i < ConteoPrestamos; i++)   //Este ciclo for se encarga de recorrer el conteo de prestamos para localizar al usuario
                {
                    if (Prestamos[i].CarneLandivar == carnelistado) //Validación que se encarga de si algún usuario del carné que ingresó coincide con uno guardado en el arreglo, se despliegen los datos
                    {
                        for (int j = 0; j < ConteoLibros; j++)
                        {
                            if (Libros[j].CódigoLibro == Prestamos[i].CodigoLibroLandivar)  //Misma validación pero con el código del libro
                            {
                                Console.WriteLine($"Título del Libro: {Libros[j].Titulo}, Autor: {Libros[j].Autor}, Código del Libro: {Libros[j].CódigoLibro}");
                            }

                        }
                    }
                }
            }
            else if (Opcion3 == 2)  //Si elije la opción 2 se muestra el catálogo de los libros que se prestaron 
            {
                for (int i = 0; i < ConteoLibros; i++)  //Recorre el arreglo y muestra todos los libros que se ingresaron
                {
                    Console.WriteLine($"Título: {Libros[i].Titulo}, Autor: {Libros[i].Autor}, Código del Libro: {Libros[i].CódigoLibro}");
                }
            }    
            else if (Opcion3 == 3)  //Su elije la opción 3 se muestra el listado de usuarios activos
            {
                for (int i = 0; i < ConteoUsuarios; i++)    //Recorre nuevamente el arreglo y despliega los usuarios que se ingresaron en el menu de ingresar datos
                {
                    Console.WriteLine($"Nombre: {Usuarios[i].Nombre}, Apellido: {Usuarios[i].Apellidos}, Carné: {Usuarios[i].Carné}");
                }
            }
            }while(Opcion3 != 4);
            break;
        
        case 3: 
            DevolverLibro(Prestamos, ref ConteoPrestamos);  //Utilización de la función local en program para devolver los libros
            break;

        case 4:
            return;

        default:
            Console.WriteLine("Opcion no válida");
            break;

    }
}while(Opcion != 5);

//Método dentro del program que permite devolver un libro (No me salía si lo colocaba en la clase de préstamos)
static void DevolverLibro(Prestamos[] Prestamos, ref int ConteoPrestamos)
{
    Console.WriteLine("Ingresa el carné del estudiante que quiere devolver un libro");
    string carné = Console.ReadLine();
    Console.WriteLine("Ingresa el código del libro que quieres devolverUsu");
    string codigolibro = Console.ReadLine();
    bool seEncontro = false;

    for (int i = 0; i < ConteoPrestamos; i++)   //Recorre el arreglo
    {
        if (Prestamos[i].CarneLandivar == carné && Prestamos[i].CodigoLibroLandivar == codigolibro) //Valida que coicidan los datos ingresados con los que están en el arreglo
        {
            seEncontro = true;

            for (int j = i; j < ConteoPrestamos - 1; j++)
            {
                Prestamos[j] = Prestamos[j + 1];
            }
            Prestamos[ConteoPrestamos - 1] = null;  //Se quita un préstamo y lo convierte en un valor nulo para el conteo dentro del arreglo
            ConteoPrestamos--;
            Console.WriteLine("Se devolvió el libro, gracias por preferirnos como biblioteca!");
            break;
        }
    }
    if (seEncontro != true)
    {
        Console.WriteLine("No hay ningun préstamo con estos datos");
    }
}



