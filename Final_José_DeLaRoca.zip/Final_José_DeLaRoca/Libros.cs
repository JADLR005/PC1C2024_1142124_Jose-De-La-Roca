﻿namespace Final_José_DeLaRoca;

public class Libros
{
    //Definimos los parámetros que necesitamos para la clase libro
    public string Titulo;
    public string Autor;
    public string CódigoLibro;

    //Definimos un método que valide el código del libro
    public bool ValidarLibro(string CódigoLibro)
    {
        if (CódigoLibro.Length > 5 || CódigoLibro.Length < 5)
        {
            if (CódigoLibro.IndexOf("L") == 1 && CódigoLibro.IndexOf("RL") == 4)
            {
                Console.WriteLine("Código de libro válido");
                return true;
            }
            else
            {
                Console.WriteLine("El libro no es de esta universidad");
                return false;
            }
        }
        return true;
    }
}
