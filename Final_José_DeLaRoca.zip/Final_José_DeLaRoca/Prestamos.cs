﻿namespace Final_José_DeLaRoca;

public class Prestamos
{
    //Primero definimos los parámetros que necesitamos para los préstamos
    public string CarneLandivar;
    public string CodigoLibroLandivar;
}
