﻿namespace Final_José_DeLaRoca;

public class Usuarios
{
    //Definimos los parámetros para la clase Usuario que luego se utilizarán para el ingreso de datos
    public string Nombre;
    public string Apellidos;
    public string Carné;

    //Creamos un método que nos apoye a validar que el carné de la Universidad sea correcto
    public bool ValidarCarne(string Carné)
    {
        if (Carné.Length < 7 || Carné.Length > 7)
        {
            Console.WriteLine("El carné que ingresaste no es de esta Universidad, ingresa tus datos nuevamente o no aparecerás en el sistema");
            return false;
        }else{
            Console.WriteLine("Carné válido de la Universidad Rafael Landívar");
            return true;
        }
    }
}

